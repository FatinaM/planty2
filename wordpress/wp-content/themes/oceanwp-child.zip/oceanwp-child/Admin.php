<?php 
/*
Template Name: Page Admin 
*/

get_header(); ?>

<?php get_footer(); ?>