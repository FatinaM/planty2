<?php get_header(); ?>
	Coucou
<?php get_footer(); ?>