<?php
/**
** activation theme
**/
function creation_theme_enfant() {
	wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
}
add_action( 'wp_enqueue_scripts', 'creation_theme_enfant' );